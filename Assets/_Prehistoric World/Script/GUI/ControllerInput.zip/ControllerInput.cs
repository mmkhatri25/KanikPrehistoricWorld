﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class ControllerInput : MonoBehaviour, IListener {
	public static ControllerInput Instance;
	public Text bulletText;
	public Text bombText;
	public Text powerBulletText;
	public Text trackBulletText;
	public Text spreadBulletText;
	public Text laserBulletText;

	public GameObject butMelee, butThrow, butChangeWeapon, butShooting, butDogge, butRun, butBreath, butJetpack, butSlide;
	public CanvasGroup ActionButtons;
    public CanvasGroup jumpButtonsCG;

    public float ButtonCooler = 0.5f;
	float buttonCooler, buttonCoolerU;
	private int ButtonCountR = 0;
	private int ButtonCountL = 0;

	private int ButtonCountU = 0;

	bool isUseJetpack;
	bool isMoveLeft = false;
	bool isMoveRight = false;
	[HideInInspector]
	public bool isLookingUp = false;

//	Player Player;
	ButtonActivated butActive;
	CallPartnerUI partner;
	RopeUI rope;
	SpecialPower specialBomb;
	WeaponChangerUI switchWeapon;
	PushAndPullUI pushPull;
	Cannon[] cannons;

	public float holdTime = 1.5f;
	float holdCounting = 0;
	WeaponChangerUI weasponChanger;
	public bool isHoding = false;
	public GameObject DirectionControl;


	// Use this for initialization
	void Awake () {
		buttonCooler = ButtonCooler;
		buttonCoolerU = ButtonCooler;
		Instance = this;
	}

	void OnEnable(){
		StopMove ();
		Invoke ("SetAgain", 0.1f);
        if (GameManager.Instance)
            DirectionControl.SetActive(GameManager.Instance.gameType == GameType.Platform);
        else
            DirectionControl.SetActive(FindObjectOfType<GameManager>().gameType == GameType.Runner);
    }

	void SetAgain(){
		if(GameManager.Instance)
			GameManager.Instance.controllerInput = this;
		butActive = FindObjectOfType<ButtonActivated> ();
		partner = FindObjectOfType<CallPartnerUI> ();
		rope = FindObjectOfType<RopeUI> ();
		specialBomb = FindObjectOfType<SpecialPower> ();
		switchWeapon = FindObjectOfType<WeaponChangerUI> ();
		weasponChanger = FindObjectOfType<WeaponChangerUI> ();
		pushPull = FindObjectOfType<PushAndPullUI> ();

		cannons = FindObjectsOfType<Cannon> ();
		isHoding = false;
	}

	void Start(){
		GameManager.Instance.controllerInput = this;
		butActive = FindObjectOfType<ButtonActivated> ();
		partner = FindObjectOfType<CallPartnerUI> ();
		rope = FindObjectOfType<RopeUI> ();
		specialBomb = FindObjectOfType<SpecialPower> ();
		switchWeapon = FindObjectOfType<WeaponChangerUI> ();
		weasponChanger = FindObjectOfType<WeaponChangerUI> ();
		pushPull = FindObjectOfType<PushAndPullUI> ();

		cannons = FindObjectsOfType<Cannon> ();
	}

	void Update(){
//		Debug.LogError (isHoldRunButton);
		UpdateButton ();

		if (GameManager.Instance.State != GameManager.GameState.Playing)
			return;
		
		bulletText.text = GlobalValue.normalBullet.ToString ();
        if (DefaultValue.Instance)
            bulletText.gameObject.SetActive(!DefaultValue.Instance.defaultNormalBulletUnlimited);

		bombText.text = GlobalValue.grenade.ToString ();
		if(powerBulletText)
		powerBulletText.text = GlobalValue.powerBullet.ToString ();
        if (DefaultValue.Instance)
            powerBulletText.gameObject.SetActive(!DefaultValue.Instance.defaultPowerBulletUnlimited);

        if (trackBulletText)
			trackBulletText.text = GlobalValue.TrackBullet.ToString ();
        if (DefaultValue.Instance)
            trackBulletText.gameObject.SetActive(!DefaultValue.Instance.defaultTrackBulletUnlimited);

        if (spreadBulletText)
			spreadBulletText.text = GlobalValue.SpreadBullet.ToString ();
        if (DefaultValue.Instance)
            spreadBulletText.gameObject.SetActive(!DefaultValue.Instance.defaultSpreadBulletUnlimited);

        if (laserBulletText)
			laserBulletText.text = GlobalValue.LaserBullet.ToString ();
        if (DefaultValue.Instance)
            laserBulletText.gameObject.SetActive(!DefaultValue.Instance.defaultLaserBulletUnlimited);

        if (isMoveLeft)
			GameManager.Instance.Player.MoveLeft ();
		else if (isMoveRight)
			GameManager.Instance.Player.MoveRight ();

		if ( buttonCooler > 0 )
		{

			buttonCooler -= 1 * Time.deltaTime ;

		}else{
			ButtonCountR = 0 ;
		}

		if ( buttonCooler > 0 )
		{

			buttonCooler -= 1 * Time.deltaTime ;

		}else{
			ButtonCountL = 0 ;
		}

		if (holdCounting > 0) {
			holdCounting -= Time.deltaTime;
		}

		if ( buttonCoolerU > 0 )
		{

			buttonCoolerU -= 1 * Time.deltaTime ;

		}else{
			ButtonCountU = 0 ;
		}

		if (delayKeepRunning > 0)
			delayKeepRunning -= Time.deltaTime;

        if (ActionButtons.alpha == 0)
        {
            holdCounting = 0;
            isHoding = false;
            buttonCooler = 0;
            buttonCoolerU = 0;
            delayKeepRunning = 0;
            GameManager.Instance.Player.CancelRangeHolding();
        }

		GameManager.Instance.Player.PowerupGunFx (holdCounting <= 0 && isHoding);

		//PC INPUT
		HandleInput ();

        //GAMEPAD INPUT
        //		GamePadInput ();
        ActionButtons.alpha = GameManager.Instance.Player.gameObject.layer == LayerMask.NameToLayer("HidingZone") ? 0 : 1;
        ActionButtons.interactable = GameManager.Instance.Player.gameObject.layer != LayerMask.NameToLayer("HidingZone");
        ActionButtons.blocksRaycasts = GameManager.Instance.Player.gameObject.layer != LayerMask.NameToLayer("HidingZone");

        if (ActionButtons.alpha == 0 && !GameManager.Instance.Player.isBreathing)
            jumpButtonsCG.ignoreParentGroups = GameManager.Instance.Player.canJumpWhenHidingZone;
        else
            jumpButtonsCG.ignoreParentGroups = false;

        //ActionButtons.SetActive (GameManager.Instance.Player.gameObject.layer != LayerMask.NameToLayer ("HidingZone"));
    }

	private void UpdateButton(){
		butChangeWeapon.SetActive (GameManager.Instance.Player.allowChangeWeapon);
		butDogge.SetActive (GameManager.Instance.Player.allowDogge);
		butMelee.SetActive (GameManager.Instance.Player.allowMelee);
		butShooting.SetActive (GameManager.Instance.Player.allowShooting);
        butThrow.SetActive(GameManager.Instance.Player.allowThrow && GlobalValue.grenade > 0);
		butRun.SetActive (GameManager.Instance.Player.runType == RunType.UseButton);
		butBreath.SetActive (GameManager.Instance.Player.allowBreath && (GameManager.Instance.Player.gameObject.layer != LayerMask.NameToLayer("HidingZone") || GameManager.Instance.Player.isBreathing));
		butJetpack.SetActive (GameManager.Instance.Player.allowJetpack);
		butSlide.SetActive (GameManager.Instance.Player.allowSlide);
//		butSwitch.SetActive (GameManager.Instance.Player.allowSwitch);
	}


	
	public void MoveLeft(bool isTouch = false){
		if (GameManager.Instance.isInDialogue || GameManager.Instance.Player.isInCannon)
			return;

		if (GameManager.Instance.Player.isClimbing && GameManager.Instance.Player.currentLadder && !GameManager.Instance.Player.currentLadder.GetComponent<Ladder8DirsZone> ())
			return;
		
		isLookingUp = false;
		
		if (GameManager.Instance.State == GameManager.GameState.Playing) {
//			Debug.LogError (isTouch +"/"+( phoneTouchRun == PhoneTouchType.RunType1) +"/"+  (delayKeepRunning > 0.19f) + delayKeepRunning);
			if (isTouch && (DefaultValue.Instance.phoneTouchRun == PhoneTouchType.RunType1) && (delayKeepRunning > 0.19f)) {
				buttonCooler = 0;
				delayKeepRunning = 0;
				ButtonCountL = 0;
//				Debug.LogError ("EXIT");
//				return;
//				Debug.LogError ("NO EXIT");
			}

//			Player.MoveLeft ();
			isMoveLeft = true;
			isMoveRight = false;

			if (isHoldRunButton) {
				Run (true);
			} else if ((buttonCooler > 0 && ButtonCountL == 1/*Number of Taps you want Minus One*/)
				|| delayKeepRunning > 0) {
//				Debug.LogError (buttonCooler  +"/"+ButtonCountL  +"/"+  (delayKeepRunning > 0) + delayKeepRunning);
//				Debug.LogError ("RUN");
				GameManager.Instance.Player.input = Vector2.left;
				GameManager.Instance.Player.Run (RunType.DoublePress);
			}
			else{
				buttonCooler = ButtonCooler ; 
				ButtonCountL += 1 ;
			}
		}
	}

	float delayKeepRunning=0;
	public void MoveRight(bool isTouch = false){
		if (GameManager.Instance.isInDialogue || GameManager.Instance.Player.isInCannon)
			return;

		if (GameManager.Instance.Player.isClimbing && GameManager.Instance.Player.currentLadder && !GameManager.Instance.Player.currentLadder.GetComponent<Ladder8DirsZone> ())
			return;

		Debug.Log ("MOVE RIGHT");
		
		isLookingUp = false;

		if (GameManager.Instance.State == GameManager.GameState.Playing) {
			if (isTouch && (DefaultValue.Instance.phoneTouchRun == PhoneTouchType.RunType1) && (delayKeepRunning > 0.19f)) {
				buttonCooler = 0;
				delayKeepRunning = 0;
				ButtonCountR = 0;
				//				Debug.LogError ("EXIT");
				//				return;
				//				Debug.LogError ("NO EXIT");
			}
//			Player.MoveRight ();
			isMoveLeft = false;
			isMoveRight = true;

			if(isHoldRunButton){
				Run (true);
			}
			else if ( (buttonCooler > 0 && ButtonCountR == 1/*Number of Taps you want Minus One*/) 
				|| delayKeepRunning>0){
				GameManager.Instance.Player.input = Vector2.right;
				GameManager.Instance.Player.Run (RunType.DoublePress);
			}

			else{
				buttonCooler = ButtonCooler ; 
				ButtonCountR += 1 ;
			}
		}
	}

	public void MoveUp(){
		
		if (GameManager.Instance.isInDialogue || GameManager.Instance.Player.isInCannon)
			return;
		
		if (GameManager.Instance.Player.isSliding)
			return;
        if (GameManager.Instance.Player.meleeAttack.isFastAttacking)
            return;

        if (GameManager.Instance.State == GameManager.GameState.Playing) {
			GameManager.Instance.Player.MoveUp ();

			if (GameManager.Instance.Player.allowFireUp)
				isLookingUp = true;

			if (GameManager.Instance.Player.runType == RunType.DoublePress && GameManager.Instance.Player.doublePressType == DoublePressType.Dogge
				&& (buttonCoolerU > 0 && ButtonCountU == 1/*Number of Taps you want Minus One*/)
				/*|| delayKeepRunning > 0*/) {
				//				Debug.LogError (buttonCooler  +"/"+ButtonCountL  +"/"+  (delayKeepRunning > 0) + delayKeepRunning);
				//				Debug.LogError ("RUN");
				GameManager.Instance.Player.input = Vector2.up;
				GameManager.Instance.Player.Run (RunType.DoublePress);
			}
			else{
				buttonCoolerU = ButtonCooler ; 
				ButtonCountU += 1 ;
			}
		}
		Debug.LogWarning (isLookingUp);
	}

	public void MoveDown(){
		if (GameManager.Instance.isInDialogue || GameManager.Instance.Player.isInCannon || GameManager.Instance.Player.isClimbOnTop)
			return;
		
		if (GameManager.Instance.State == GameManager.GameState.Playing)
			GameManager.Instance.Player.MoveDown ();
	}

	public void StopLadder(){
		if (GameManager.Instance.Player.isSliding)
			return;
		
		if (GameManager.Instance.State == GameManager.GameState.Playing) {
			GameManager.Instance.Player.StopLadder ();
			isLookingUp = false;


			StopMove ();
		}
	}

	public void StopMoveForTouch(int _dir){
////		if (isHoldRunButton && GameManager.Instance.Player.runType == RunType.UseButton && ((_dir == 1 && isMoveLeft) || (_dir == -1 && isMoveRight)))
////			return;
////
////		if (_dir == 1 && isMoveLeft && GameManager.Instance.Player.runType == RunType.DoublePress) {
////			return;
////		} else if (_dir == -1 && isMoveRight && GameManager.Instance.Player.runType == RunType.DoublePress) {
////			return;
////		}
//
//		if (GameManager.Instance && GameManager.Instance.State == GameManager.GameState.Playing) {
////			Debug.LogError ("STOP RUN");
//			GameManager.Instance.Player.StopMove ();
//			if (phoneTouchRun == PhoneTouchType.RunType1 && ((_dir == -1 && isMoveRight) || (_dir == 1 && isMoveLeft) )) {
//				delayKeepRunning = -1;
//				buttonCooler = -1;
//			} else
//				delayKeepRunning = 0.2f;
//			
////			delayKeepRunning = 0.2f;
//		}
//		isMoveLeft = isMoveRight = false;
//		isLookingUp = false;

		if (isHoldRunButton && GameManager.Instance.Player.runType == RunType.UseButton && ((_dir == 1 && isMoveLeft) || (_dir == -1 && isMoveRight)))
			return;

		if (_dir == 1 && isMoveLeft && GameManager.Instance.Player.runType == RunType.DoublePress) {
			return;
		} else if (_dir == -1 && isMoveRight && GameManager.Instance.Player.runType == RunType.DoublePress) {
			return;
		}

		if (GameManager.Instance && GameManager.Instance.State == GameManager.GameState.Playing) {
			//			Debug.LogError ("STOP RUN");
			GameManager.Instance.Player.StopMove ();
			delayKeepRunning = 0.2f;
		}
		isMoveLeft = isMoveRight = false;
		isLookingUp = false;
	}


	public void StopMove(int _dir = 0){

		if (isHoldRunButton && GameManager.Instance.Player.runType == RunType.UseButton && ((_dir == 1 && isMoveLeft) || (_dir == -1 && isMoveRight)))
			return;

		if (_dir == 1 && isMoveLeft && GameManager.Instance.Player.runType == RunType.DoublePress) {
			return;
		} else if (_dir == -1 && isMoveRight && GameManager.Instance.Player.runType == RunType.DoublePress) {
			return;
		}
		
		if (GameManager.Instance && GameManager.Instance.State == GameManager.GameState.Playing) {
//			Debug.LogError ("STOP RUN");
			GameManager.Instance.Player.StopMove ();
			delayKeepRunning = 0.2f;
		}
		isMoveLeft = isMoveRight = false;
		isLookingUp = false;
	}

	public void Jump (){
		Debug.Log (GameManager.Instance.Player.isInCannon);
		if (GameManager.Instance.State == GameManager.GameState.Playing) {
			if (GameManager.Instance.isInDialogue)
				butActive.TriggerButtonAction ();
			else if (GameManager.Instance.Player.isInCannon) {
				Debug.Log ("F");
				foreach (var obj in cannons)
					obj.FireCannon ();
				return;
			}

			if (MenuManager.Instance.isShopInGame)
				MenuManager.Instance.OpenShop ();
			else if(RopeUI.instance.CurrentRope){
				if (GameManager.Instance.Player.isRoping || GameManager.Instance.Player.isHaningRope) {
					GameManager.Instance.Player.Jump ();
				} else {
					CatchRope ();
				}
			}
//			else if(pushPull.isDragable){
//				DragStart ();
//			}
			else if(GameManager.Instance.isInDialogue){
				return;
			}
			else
				GameManager.Instance.Player.Jump ();
		}
	}

	public void JumpOff(){
		if (GameManager.Instance.State == GameManager.GameState.Playing) {
			if (pushPull.isDragable) {
				DragEnd ();
			} else
				GameManager.Instance.Player.JumpOff ();
		}
	}

	public void UseJetpack (){
		if (GameManager.Instance.Player.isInCannon)
			return;
		if (GameManager.Instance.Player.isSliding)
			return;
        if (GameManager.Instance.Player.meleeAttack.isFastAttacking)
            return;
        if (GameManager.Instance.Player.isClimbing)
			return;
		if (GameManager.Instance.Player.isGrabRopePoint || GameManager.Instance.Player.isHaningRope ||GameManager.Instance.Player.isRoping)
			return;
        if (GameManager.Instance.Player.meleeAttack && GameManager.Instance.Player.meleeAttack.currentCombo != 0)
            return;

        if (GameManager.Instance.Player.isClimbOnTop)
            return;
        if (GameManager.Instance.Player.wallSliding)
            return;
        if (GameManager.Instance.Player.isClimbingVine)
            return;
        if (GameManager.Instance.Player.isGrabbingLedge)
            return;

        if (GameManager.Instance.State == GameManager.GameState.Playing) {
			GameManager.Instance.Player.UseJetpack ();
		}
	}

	public void StopUseJetpack(){
		if (GameManager.Instance.Player.isSliding)
			return;
		if (GameManager.Instance.Player.isClimbing)
			return;
        if (GameManager.Instance.Player.meleeAttack.isFastAttacking)
            return;
        if (GameManager.Instance.Player.isGrabRopePoint || GameManager.Instance.Player.isHaningRope ||GameManager.Instance.Player.isRoping)
			return;
        if (GameManager.Instance.Player.meleeAttack && GameManager.Instance.Player.meleeAttack.currentCombo != 0)
            return;

        if (GameManager.Instance.Player.isClimbOnTop)
            return;
        if (GameManager.Instance.Player.wallSliding)
            return;
        if (GameManager.Instance.Player.isClimbingVine)
            return;
        if (GameManager.Instance.Player.isGrabbingLedge)
            return;

        if (GameManager.Instance.State == GameManager.GameState.Playing)
			GameManager.Instance.Player.StopUseJetpack ();
	}

	public void MeleeAttack(){
		if (GameManager.Instance.Player.isInCannon)
			return;

		if (GameManager.Instance.Player.isClimbing)
			return;
		if (GameManager.Instance.Player.isSliding)
			return;
        if (GameManager.Instance.Player.meleeAttack.isFastAttacking)
            return;
        if (GameManager.Instance.Player.isClimbingVine)
            return;
        if (GameManager.Instance.Player.wallSliding && !GameManager.Instance.Player.useMeleeWhenWallSlide)
			return;
        if (GameManager.Instance.Player.isInCannon)
            return;

        //if (GameManager.Instance.Player.isRoping && !GameManager.Instance.Player.allowRopingShoot)
        //	return;
        if (GameManager.Instance.Player.PlayerState == PlayerState.Water && !GameManager.Instance.Player.allowWaterZoneShoot)
			return;
		if ((GameManager.Instance.Player.isHaningRope) && !GameManager.Instance.Player.allowHangingRopeShoot)
			return;
        if (GameManager.Instance.Player.isClimbingVine)
            return;
        if ((GameManager.Instance.Player.isGrabRopePoint) && !GameManager.Instance.Player.allowRopeType2Shoot)
			return;
		if (GameManager.Instance.Player.isClimbOnTop && !GameManager.Instance.Player.allowPipeShoot)
			return;

		if (GameManager.Instance.Player.isRoping)
			return;
		if (GameManager.Instance.Player.isHaningRope)
			return;
		if (GameManager.Instance.Player.isClimbOnTop)
			return;
		if (GameManager.Instance.Player.isGrabbingLedge)
			return;
		if (GameManager.Instance.Player.isGrabRopePoint)
			return;

		if (GameManager.Instance.Player.isRunning && !GameManager.Instance.Player.allowShootingRun)
			return;
        if (GameManager.Instance.Player.isGrabbingLedge)
            return;

        if (GameManager.Instance.Player.allowSlashOnHoldAttack)
			OnHoldingWait ();
		
//		if (GameManager.Instance.State == GameManager.GameState.Playing)
//			GameManager.Instance.Player.MeleeAttack ();
	}

	public void MeleeAttackUp(){
		if (GameManager.Instance.Player.wallSliding && !GameManager.Instance.Player.useMeleeWhenWallSlide)
			return;

		if (GameManager.Instance.Player.isClimbing)
			return;
		if (GameManager.Instance.Player.isSliding)
			return;
        if (GameManager.Instance.Player.meleeAttack.isFastAttacking)
            return;
        if (GameManager.Instance.Player.isClimbingVine)
            return;
        if (GameManager.Instance.Player.isInCannon)
            return;
        if (GameManager.Instance.Player.isGrabbingLedge)
            return;


        if (holdCounting <= 0 && (GameManager.Instance.controllerInput.isLookingUp))
        {
            isHoding = false;
            return;
        }

        if (holdCounting <= 0) {
			if (GameManager.Instance.Player.allowSlashOnHoldAttack)
				GameManager.Instance.Player.meleeAttack.AttackPowerBullet ();

			if (GameManager.Instance.State == GameManager.GameState.Playing)
				GameManager.Instance.Player.MeleeAttack ();
		} else {
			if (GameManager.Instance.State == GameManager.GameState.Playing)
				GameManager.Instance.Player.MeleeAttack ();
		}

		isHoding = false;
	}

	public void RangeAttackDown(bool powerBullet){
		if (GameManager.Instance.Player.isInCannon)
			return;
		
		if (GameManager.Instance.State == GameManager.GameState.Playing) {
			GameManager.Instance.Player.RangeAttack (powerBullet, false);

			if (GameManager.Instance.Player.allowHoldNormalAttack && !powerBullet) {
				OnHoldingWait ();
				isHoding = true;
			} else if (GameManager.Instance.Player.allowHoldDartBullet && powerBullet) {
				OnHoldingWait ();
				isHoding = true;
			}
		}
	}
	public void RangeAttackUp(bool powerBullet){
		if (GameManager.Instance.State == GameManager.GameState.Playing) {
			GameManager.Instance.Player.RangeAttack (powerBullet, true);

			isHoding = false;
		}
	}

	public void ThrowGrenade(){
		if (GameManager.Instance.Player.isInCannon)
			return;

		if (GameManager.Instance.Player.isClimbing)
			return;

		if (GameManager.Instance.Player.isSliding)
			return;

        if (GameManager.Instance.Player.meleeAttack.isFastAttacking)
            return;
        if (GameManager.Instance.Player.isClimbingVine)
            return;

        if (GameManager.Instance.State == GameManager.GameState.Playing)
			GameManager.Instance.Player.ThrowGrenade ();
	}

	public void RunAndSlide(){
		if (GameManager.Instance.Player.isInCannon)
			return;
        if (GameManager.Instance.Player.meleeAttack && GameManager.Instance.Player.meleeAttack.currentCombo != 0)
            return;

        if (GameManager.Instance.Player.isClimbingLadder8Dir)
            return;
        if (GameManager.Instance.Player.isClimbOnTop)
            return;
        if (GameManager.Instance.Player.PlayerState == PlayerState.Water)
            return;

        if (GameManager.Instance.State == GameManager.GameState.Playing)
			GameManager.Instance.Player.RunAndSlide ();
	}

	bool isHoldRunButton=false;
	public void Run(bool forceRun = false){
		if (GameManager.Instance.Player.isInCannon)
			return;

		if (GameManager.Instance.State == GameManager.GameState.Playing) {
			GameManager.Instance.Player.Run (RunType.UseButton, forceRun);
			isHoldRunButton = true;

			if (DefaultValue.Instance.runButtonType == RunButtonType.SinglePress)
				isHoldRunButton = false;
		}
	}

	public void RunOff(){
		if (GameManager.Instance.Player.isInCannon)
			return;

		if (GameManager.Instance.State == GameManager.GameState.Playing) {
//			GameManager.Instance.Player.Run (RunType.UseButton);
			if (DefaultValue.Instance.runButtonType == RunButtonType.Holding)
				GameManager.Instance.Player.StopRunning ();
			isHoldRunButton = false;
		}
	}

	//press button down
	public void OnHoldingWait(){
		holdCounting = holdTime;
		isHoding = true;
		Debug.Log ("OnHoldingWait");
	}

	public void FireTrackBullet(){
		if (GameManager.Instance.Player.isInCannon)
			return;
		
		if (GameManager.Instance.State == GameManager.GameState.Playing) {
			GameManager.Instance.Player.FireTrackBullet (holdCounting <= 0);
			isHoding = false;
		}
	}

	public void FireSpradBullet(){
		if (GameManager.Instance.Player.isInCannon)
			return;
		
		if (GameManager.Instance.State == GameManager.GameState.Playing) {
			GameManager.Instance.Player.FireSpradBullet (holdCounting <= 0);
			isHoding = false;
		}
	}

	public void FireLaser(){
		if (GameManager.Instance.Player.isInCannon)
			return;
		
		if (GameManager.Instance.State == GameManager.GameState.Playing) {
			GameManager.Instance.Player.FireLaser (holdCounting <= 0);
			isHoding = false;
		}
	}

	private void CallPartner(){
        partner.CallPartner ();
	}

	private void CatchRope(){
		if (GameManager.Instance.Player.isInCannon)
			return;
		
		rope.Click ();
	}

	public void SpecialWeapon(){
		if (GameManager.Instance.Player.isInCannon)
			return;
		
		specialBomb.DoExplosion ();
		isHoding = false;
	}

	private void SpecialWeaponHolding(){
		specialBomb.OnHolding ();
		OnHoldingWait ();
		isHoding = true;

	}



	private void SwitchWeapon(){
		switchWeapon.Next ();
	}

	private void DragStart(){
		pushPull.Drag ();
	}

	private void DragEnd(){
		pushPull.Stop ();
	}

	public void Dogge(){
		GameManager.Instance.Player.Dogge ();
	}

	public void ApplyKey(){
		;
	}

	//GAMEPAD
	bool gamepadMoveL =false;
	bool gamepadMoveR =false;
	float preX,preY;
	int weapon = 0;

	private void GamePadInput(){
		float x = Input.GetAxisRaw ("Horizontal");
		float y = Input.GetAxisRaw ("Vertical");
//		Debug.Log (preX + "/" + preY);
		//X
		if (x == 1 && x != preX) {
			MoveRight ();
			preX = x;
		} else if (x == -1 && x != preX) {
			MoveLeft ();
			preX = x;
		} else if (x == 0 && x != preX) {
			StopMove ();
			preX = 0;
		}

		//Y
		if (y == 1 && y != preY) {
			MoveUp ();
			preY = y;
		} else if (y == -1 && y != preY) {
			MoveDown ();
			preY = y;
		} else if (y == 0) {
			if (preY == 1)
				StopMove ();
			else if (preY == -1)
				StopLadder ();
			preY = 0;
		}


		//Firing

		if (Input.GetButtonDown ("B") || Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Shooting : DefaultValueKeyboard.Instance.Shooting)) {
			AttackButtonDown ();
		} else if (Input.GetButtonUp ("B") || Input.GetKeyUp (DefaultValue.Instance? DefaultValue.Instance.Shooting : DefaultValueKeyboard.Instance.Shooting)) {
			AttackButtonsUp ();
		}
	}

	public void AttackButtonDown(){
        if (GameManager.Instance.Player.meleeAttack && GameManager.Instance.Player.meleeAttack.currentCombo != 0)
            return;
        //		Debug.LogWarning ("AttackButtonDown");
        if (GameManager.Instance.Player.isJumpCombox3)
			return;

		if (GameManager.Instance.Player.isClimbing)
			return;
		if (GameManager.Instance.Player.isSliding)
			return;
        if (GameManager.Instance.Player.meleeAttack.isFastAttacking)
            return;
   //     if (GameManager.Instance.Player.isRoping && !GameManager.Instance.Player.allowRopingShoot)
			//return;
		if (GameManager.Instance.Player.PlayerState == PlayerState.Water && !GameManager.Instance.Player.allowWaterZoneShoot)
			return;
        if (GameManager.Instance.Player.isClimbingVine)
            return;
        if (GameManager.Instance.Player.isGrabbingLedge)
            return;
        if ((GameManager.Instance.Player.isHaningRope) && !GameManager.Instance.Player.allowHangingRopeShoot)
			return;
		if ((GameManager.Instance.Player.isGrabRopePoint) && !GameManager.Instance.Player.allowRopeType2Shoot)
			return;
		if (GameManager.Instance.Player.isClimbOnTop && !GameManager.Instance.Player.allowPipeShoot)
			return;

		if (GameManager.Instance.Player.isRunning && !GameManager.Instance.Player.allowShootingRun)
			return;
//		if (GameManager.Instance.Player.isGrabRopePoint)
//			return;
		
//		Debug.LogError ("THIS1");

		if (GameManager.Instance.Player.wallSliding && !GameManager.Instance.Player.useShootingWhenWallSlide)
			return;

//		Debug.LogError ("HOLD" + GameManager.Instance.Player.isGrabRopePoint + "/" +GameManager.Instance.Player.allowHangingRopeShoot);
//		Debug.LogError (weasponChanger);
		for (int i = 0; i < weasponChanger.listButtons.Length; i++) {
			if (weasponChanger.listButtons [i].gameObject.activeInHierarchy) {
				weapon = i;
				Debug.Log ("WEAPON" + i);
				switch (weapon) {
				case 0:
					RangeAttackDown (false);
					break;
				case 1:
					RangeAttackDown (true);
					break;
				case 5:
//					if (GameManager.Instance.Player.allowHoldSpecialAttack)
//						SpecialWeaponHolding ();
					break;
				case 2:
					if (GameManager.Instance.Player.allowHoldTrackBullet) {
						OnHoldingWait ();
					}
					break;
				case 3:
					if (GameManager.Instance.Player.allowHoldSpreadBullet)
						OnHoldingWait ();
					break;
				case 4:
					if (GameManager.Instance.Player.allowHoldLaserBullet)
						OnHoldingWait ();
					break;
				default:
					break;
				}
			}
		}
//		Debug.LogError ("THIS3");
	}

	public void AttackButtonsUp(){

        if (GameManager.Instance.Player.meleeAttack && GameManager.Instance.Player.meleeAttack.currentCombo != 0)
            return;
        if (GameManager.Instance.Player.isClimbing)
			return;
		if (GameManager.Instance.Player.isSliding)
			return;
        if (GameManager.Instance.Player.meleeAttack.isFastAttacking)
            return;
        if (GameManager.Instance.Player.isClimbingVine)
            return;
        //     if (GameManager.Instance.Player.isRoping && !GameManager.Instance.Player.allowRopingShoot)
        //return;
        if (GameManager.Instance.Player.PlayerState == PlayerState.Water && !GameManager.Instance.Player.allowWaterZoneShoot)
			return;
		if ((GameManager.Instance.Player.isHaningRope) && !GameManager.Instance.Player.allowHangingRopeShoot)
			return;
		if ((GameManager.Instance.Player.isGrabRopePoint) && !GameManager.Instance.Player.allowRopeType2Shoot)
			return;
		if (GameManager.Instance.Player.isClimbOnTop && !GameManager.Instance.Player.allowPipeShoot)
			return;
		if (GameManager.Instance.Player.isGrabbingLedge)
			return;
//		if (GameManager.Instance.Player.isGrabRopePoint)
//			return;
		
		if (GameManager.Instance.Player.isJumpCombox3)
			return;

		if (GameManager.Instance.Player.isRunning && !GameManager.Instance.Player.allowShootingRun)
			return;

		if (GameManager.Instance.Player.wallSliding && !GameManager.Instance.Player.useShootingWhenWallSlide)
			return;
		
		switch (weapon) {
		case 0:
			RangeAttackUp (false);
			break;
		case 1:
			RangeAttackUp (true);
			break;
		case 5:
			SpecialWeapon ();
			break;
		case 2:
			FireTrackBullet ();
			break;
		case 3:
			FireSpradBullet ();
			break;
		case 4:
			FireLaser ();
			break;
		default:
			break;
		}
	}

	//PC INPUT
	private void HandleInput(){
		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Left : DefaultValueKeyboard.Instance.Left))
			MoveLeft ();
		else if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Right : DefaultValueKeyboard.Instance.Right))
			MoveRight ();
		else if(Input.GetKeyUp(DefaultValue.Instance? DefaultValue.Instance.Left : DefaultValueKeyboard.Instance.Left))
			StopMove (-1);
		else if(Input.GetKeyUp(DefaultValue.Instance? DefaultValue.Instance.Right : DefaultValueKeyboard.Instance.Right))
			StopMove (1);

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Down : DefaultValueKeyboard.Instance.Down))
			MoveDown ();
		else if (Input.GetKeyUp (DefaultValue.Instance? DefaultValue.Instance.Down : DefaultValueKeyboard.Instance.Down))
			StopMove ();

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Up : DefaultValueKeyboard.Instance.Up))
			MoveUp ();
		else if (Input.GetKeyUp (DefaultValue.Instance? DefaultValue.Instance.Up : DefaultValueKeyboard.Instance.Up)) {
			StopLadder ();
		}

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Throw : DefaultValueKeyboard.Instance.Throw))
			ThrowGrenade ();

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Run : DefaultValueKeyboard.Instance.Run))
			Run ();

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Jetpack : DefaultValueKeyboard.Instance.Jetpack))
			UseJetpack ();
		else if (Input.GetKeyUp (DefaultValue.Instance? DefaultValue.Instance.Jetpack : DefaultValueKeyboard.Instance.Jetpack))
			StopUseJetpack ();

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.PushandPull : DefaultValueKeyboard.Instance.PushandPull))
			FindObjectOfType<PushAndPullUI> ().Drag ();
		else if (Input.GetKeyUp (DefaultValue.Instance? DefaultValue.Instance.PushandPull : DefaultValueKeyboard.Instance.PushandPull))
			FindObjectOfType<PushAndPullUI> ().Stop ();

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Slide : DefaultValueKeyboard.Instance.Slide))
			RunAndSlide ();

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Jump : DefaultValueKeyboard.Instance.Jump)) {
				Jump();
		}

		if (Input.GetKeyUp (DefaultValue.Instance? DefaultValue.Instance.Jump : DefaultValueKeyboard.Instance.Jump)) {
				JumpOff ();
		}

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Melee : DefaultValueKeyboard.Instance.Melee)) {
			MeleeAttack ();
		}

		if (Input.GetKeyUp (DefaultValue.Instance? DefaultValue.Instance.Melee : DefaultValueKeyboard.Instance.Melee)) {
			MeleeAttackUp();
		}

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.CallPartner : DefaultValueKeyboard.Instance.CallPartner))
			CallPartner ();

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.CatchRope : DefaultValueKeyboard.Instance.CatchRope))
			CatchRope ();

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.WeaponSwitch : DefaultValueKeyboard.Instance.WeaponSwitch))
			SwitchWeapon ();

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Dogge : DefaultValueKeyboard.Instance.Dogge))
			Dogge ();

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Pause : DefaultValueKeyboard.Instance.Pause))
			MenuManager.Instance.Pause ();

		if (Input.GetKeyDown (DefaultValue.Instance? DefaultValue.Instance.Shooting : DefaultValueKeyboard.Instance.Shooting)) {
			AttackButtonDown ();
		} else if (Input.GetKeyUp (DefaultValue.Instance? DefaultValue.Instance.Shooting : DefaultValueKeyboard.Instance.Shooting)) {
			AttackButtonsUp ();
		}
	}

	#region IListener implementation

	public void IPlay ()
	{
		
	}

	public void ISuccess ()
	{
		
	}

	public void IPause ()
	{
		
	}

	public void IUnPause ()
	{
		
	}

	public void IGameOver ()
	{
		isHoding = false;
	}

	public void IOnRespawn ()
	{
		Debug.Log ("StopMove");
		StopMove ();
		isHoding = false;
	}


	public void IOnStopMovingOn ()
	{
	}

	public void IOnStopMovingOff ()
	{
	}
	#endregion

	void OnDisable(){
		StopMove ();
	}
}
